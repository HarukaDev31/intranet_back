import React, { useEffect } from 'react';
import Calendar from './components/Calendar';
import Header from './components/Header';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <Calendar />
      </main>
    </div>
  );
}

export default App;
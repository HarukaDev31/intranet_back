import React, { useState } from 'react';
import { CalendarDays, Check, ChevronDown, ChevronUp, Edit } from 'lucide-react';
import { getDaysInMonth } from '../utils/dateUtils';

interface MonthProps {
  month: string;
  monthIndex: number;
  selectedDays: Set<number>;
  toggleDay: (month: string, day: number) => void;
  toggleAllDaysInMonth: (month: string, daysInMonth: number) => void;
}

const Month: React.FC<MonthProps> = ({ 
  month, 
  monthIndex, 
  selectedDays, 
  toggleDay,
  toggleAllDaysInMonth
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const daysInMonth = getDaysInMonth(new Date().getFullYear(), monthIndex);
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden transition-all duration-300 hover:shadow-md">
      <div className="flex items-center justify-between p-4 border-b border-gray-100">
        <div className="flex items-center space-x-2">
          <CalendarDays className="text-blue-500 h-5 w-5" />
          <h3 className="font-medium text-gray-800">{month.toUpperCase()}</h3>
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => toggleAllDaysInMonth(month, daysInMonth)}
            className="text-sm text-blue-600 hover:text-blue-800 transition-colors flex items-center"
            title={selectedDays.size === daysInMonth ? "Deseleccionar todos" : "Seleccionar todos"}
          >
            <Check className="h-4 w-4 mr-1" />
            <span>{selectedDays.size === daysInMonth ? "Deseleccionar todos" : "Seleccionar todos"}</span>
          </button>
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 rounded-full hover:bg-gray-100 transition-colors"
          >
            {isExpanded ? 
              <ChevronUp className="h-5 w-5 text-gray-500" /> : 
              <ChevronDown className="h-5 w-5 text-gray-500" />
            }
          </button>
        </div>
      </div>
      
      <div className={`transition-all duration-300 ${isExpanded ? 'max-h-96' : 'max-h-28'} overflow-hidden`}>
        {/* Days selection summary (always visible) */}
        <div className="p-4 bg-gray-50">
          <div className="flex flex-wrap items-center gap-2">
            {Array.from(selectedDays).sort((a, b) => a - b).map(day => (
              <span 
                key={`${month}-${day}`}
                className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-blue-800 text-sm font-medium"
              >
                {day}
              </span>
            ))}
            {selectedDays.size === 0 && (
              <span className="text-gray-500 text-sm">No hay días seleccionados</span>
            )}
          </div>
        </div>
        
        {/* Full calendar grid (expandable) */}
        <div className="p-4">
          <div className="grid grid-cols-7 gap-1">
            {['D', 'L', 'M', 'X', 'J', 'V', 'S'].map(day => (
              <div key={day} className="h-8 flex items-center justify-center text-xs font-medium text-gray-500">
                {day}
              </div>
            ))}
            
            {/* Empty cells for proper day alignment */}
            {Array.from({ length: new Date(new Date().getFullYear(), monthIndex, 1).getDay() }).map((_, i) => (
              <div key={`empty-${i}`} className="h-8"></div>
            ))}
            
            {/* Actual days */}
            {Array.from({ length: daysInMonth }).map((_, i) => {
              const day = i + 1;
              const isSelected = selectedDays.has(day);
              
              return (
                <button
                  key={`${month}-${day}`}
                  onClick={() => toggleDay(month, day)}
                  className={`h-8 w-8 rounded-full flex items-center justify-center text-sm transition-all duration-150 ${
                    isSelected 
                      ? 'bg-blue-500 text-white hover:bg-blue-600' 
                      : 'hover:bg-gray-100 text-gray-800'
                  }`}
                >
                  {day}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Month;
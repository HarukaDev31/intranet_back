import React, { useState, useEffect } from 'react';
import Month from './Month';
import { months } from '../utils/constants';

const Calendar = () => {
  const [selectedDays, setSelectedDays] = useState<Record<string, Set<number>>>({});

  useEffect(() => {
    // Initialize with empty sets for each month
    const initialSelectedDays: Record<string, Set<number>> = {};
    months.forEach(month => {
      initialSelectedDays[month] = new Set([23, 24, 25, 28, 29, 30]); // Initial days from mockup
    });
    setSelectedDays(initialSelectedDays);

    // Add jQuery for animations
    const script = document.createElement('script');
    script.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
    script.async = true;
    document.body.appendChild(script);
    
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const toggleDay = (month: string, day: number) => {
    setSelectedDays(prev => {
      const newSelectedDays = { ...prev };
      const monthSet = new Set(newSelectedDays[month]);
      
      if (monthSet.has(day)) {
        monthSet.delete(day);
      } else {
        monthSet.add(day);
      }
      
      newSelectedDays[month] = monthSet;
      return newSelectedDays;
    });
  };

  const toggleAllDaysInMonth = (month: string, daysInMonth: number) => {
    setSelectedDays(prev => {
      const newSelectedDays = { ...prev };
      const monthSet = new Set(newSelectedDays[month]);
      
      // If all days are already selected, deselect all
      if (monthSet.size === daysInMonth) {
        monthSet.clear();
      } else {
        // Otherwise, select all days
        for (let i = 1; i <= daysInMonth; i++) {
          monthSet.add(i);
        }
      }
      
      newSelectedDays[month] = monthSet;
      return newSelectedDays;
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {months.map((month, index) => (
        <Month 
          key={month}
          month={month}
          monthIndex={index}
          selectedDays={selectedDays[month] || new Set()}
          toggleDay={toggleDay}
          toggleAllDaysInMonth={toggleAllDaysInMonth}
        />
      ))}
    </div>
  );
};

export default Calendar;